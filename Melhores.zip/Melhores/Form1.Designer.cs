﻿namespace Melhores
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMostrar = new Button();
            btnLimpar = new Button();
            grpbFruta = new GroupBox();
            rdLaranja = new RadioButton();
            rdManga = new RadioButton();
            grpbSalgado = new GroupBox();
            rdCoxinha = new RadioButton();
            rdPastel = new RadioButton();
            grpbFruta.SuspendLayout();
            grpbSalgado.SuspendLayout();
            SuspendLayout();
            // 
            // btnMostrar
            // 
            btnMostrar.Location = new Point(191, 349);
            btnMostrar.Name = "btnMostrar";
            btnMostrar.Size = new Size(163, 57);
            btnMostrar.TabIndex = 0;
            btnMostrar.Text = "MOSTRAR";
            btnMostrar.UseVisualStyleBackColor = true;
            btnMostrar.Click += btnMostrar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(421, 349);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(163, 57);
            btnLimpar.TabIndex = 1;
            btnLimpar.Text = "LIMPAR";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // grpbFruta
            // 
            grpbFruta.Controls.Add(rdLaranja);
            grpbFruta.Controls.Add(rdManga);
            grpbFruta.Font = new Font("Arial", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grpbFruta.Location = new Point(179, 55);
            grpbFruta.Name = "grpbFruta";
            grpbFruta.Size = new Size(409, 100);
            grpbFruta.TabIndex = 2;
            grpbFruta.TabStop = false;
            grpbFruta.Text = "Melhor Fruta";
            // 
            // rdLaranja
            // 
            rdLaranja.AutoSize = true;
            rdLaranja.Location = new Point(227, 45);
            rdLaranja.Name = "rdLaranja";
            rdLaranja.Size = new Size(110, 31);
            rdLaranja.TabIndex = 1;
            rdLaranja.TabStop = true;
            rdLaranja.Text = "Laranja";
            rdLaranja.UseVisualStyleBackColor = true;
            // 
            // rdManga
            // 
            rdManga.AutoSize = true;
            rdManga.Location = new Point(6, 45);
            rdManga.Name = "rdManga";
            rdManga.Size = new Size(103, 31);
            rdManga.TabIndex = 0;
            rdManga.TabStop = true;
            rdManga.Text = "Manga";
            rdManga.UseVisualStyleBackColor = true;
            // 
            // grpbSalgado
            // 
            grpbSalgado.Controls.Add(rdCoxinha);
            grpbSalgado.Controls.Add(rdPastel);
            grpbSalgado.Font = new Font("Arial", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grpbSalgado.Location = new Point(185, 215);
            grpbSalgado.Name = "grpbSalgado";
            grpbSalgado.Size = new Size(403, 100);
            grpbSalgado.TabIndex = 3;
            grpbSalgado.TabStop = false;
            grpbSalgado.Text = "Melhor Salgado";
            // 
            // rdCoxinha
            // 
            rdCoxinha.AutoSize = true;
            rdCoxinha.Location = new Point(6, 48);
            rdCoxinha.Name = "rdCoxinha";
            rdCoxinha.Size = new Size(117, 31);
            rdCoxinha.TabIndex = 1;
            rdCoxinha.TabStop = true;
            rdCoxinha.Text = "Coxinha";
            rdCoxinha.UseVisualStyleBackColor = true;
            // 
            // rdPastel
            // 
            rdPastel.AutoSize = true;
            rdPastel.Location = new Point(236, 48);
            rdPastel.Name = "rdPastel";
            rdPastel.Size = new Size(97, 31);
            rdPastel.TabIndex = 0;
            rdPastel.TabStop = true;
            rdPastel.Text = "Pastel";
            rdPastel.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(grpbSalgado);
            Controls.Add(grpbFruta);
            Controls.Add(btnLimpar);
            Controls.Add(btnMostrar);
            Name = "Form1";
            Text = "Os melhores";
            grpbFruta.ResumeLayout(false);
            grpbFruta.PerformLayout();
            grpbSalgado.ResumeLayout(false);
            grpbSalgado.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnMostrar;
        private Button btnLimpar;
        private GroupBox grpbFruta;
        private RadioButton rdManga;
        private RadioButton rdLaranja;
        private GroupBox grpbSalgado;
        private RadioButton rdCoxinha;
        private RadioButton rdPastel;
    }
}
