namespace Melhores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            Boolean caso = true;
            String fruta = "";
            if (rdManga.Checked)
            {
                fruta = rdManga.Text;
            }
            else
                if (rdLaranja.Checked)
            {
                fruta = rdLaranja.Text;
            }
            else
            {
                MessageBox.Show("Nenhuma fruta selecionada");
                caso = false;
            }
            String salgado = "";
            if (rdCoxinha.Checked)
            {
                salgado = rdCoxinha.Text;
            }
            else
            {
                if (rdPastel.Checked)
                {
                    salgado = rdPastel.Text;
                }
                else
                {
                    MessageBox.Show("Nenhum salgado selecionado");
                    caso = false;
                }
            }
            if (caso)
            {
                MessageBox.Show("Fruta escolhida: " + fruta + "\n" + "Salgado escolhido: " + salgado);
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rdCoxinha.Checked = false; rdPastel.Checked = false; rdLaranja.Checked = false; rdManga.Checked = false;
        }
    }
}
