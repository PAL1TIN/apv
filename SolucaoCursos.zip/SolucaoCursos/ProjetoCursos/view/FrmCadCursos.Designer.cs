﻿namespace ProjetoCursos.view
{
    partial class FrmCadCursos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCadCursos));
            lblNomeCurso = new Label();
            lblTurma = new Label();
            gbTipo = new GroupBox();
            rdMobile = new RadioButton();
            rdWeb = new RadioButton();
            gbStatus = new GroupBox();
            rdDesativado = new RadioButton();
            rdAtivo = new RadioButton();
            txtNomeCurso = new TextBox();
            cmbTurma = new ComboBox();
            toolStrip1 = new ToolStrip();
            btnNovo = new ToolStripButton();
            toolStripSeparator1 = new ToolStripSeparator();
            btnSalvar = new ToolStripButton();
            toolStripSeparator2 = new ToolStripSeparator();
            btnListar = new ToolStripButton();
            toolStripSeparator3 = new ToolStripSeparator();
            btnExcluir = new ToolStripButton();
            gbTipo.SuspendLayout();
            gbStatus.SuspendLayout();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // lblNomeCurso
            // 
            lblNomeCurso.AutoSize = true;
            lblNomeCurso.Font = new Font("Arial", 14.25F);
            lblNomeCurso.Location = new Point(12, 120);
            lblNomeCurso.Name = "lblNomeCurso";
            lblNomeCurso.Size = new Size(154, 22);
            lblNomeCurso.TabIndex = 0;
            lblNomeCurso.Text = "Nome do Curso: ";
            // 
            // lblTurma
            // 
            lblTurma.AutoSize = true;
            lblTurma.Font = new Font("Arial", 14.25F);
            lblTurma.Location = new Point(12, 172);
            lblTurma.Name = "lblTurma";
            lblTurma.Size = new Size(73, 22);
            lblTurma.TabIndex = 1;
            lblTurma.Text = "Turma: ";
            // 
            // gbTipo
            // 
            gbTipo.Controls.Add(rdMobile);
            gbTipo.Controls.Add(rdWeb);
            gbTipo.Font = new Font("Arial", 14.25F);
            gbTipo.Location = new Point(66, 239);
            gbTipo.Name = "gbTipo";
            gbTipo.Size = new Size(243, 62);
            gbTipo.TabIndex = 2;
            gbTipo.TabStop = false;
            gbTipo.Text = "TIPO";
            // 
            // rdMobile
            // 
            rdMobile.AutoSize = true;
            rdMobile.Location = new Point(97, 30);
            rdMobile.Name = "rdMobile";
            rdMobile.Size = new Size(84, 26);
            rdMobile.TabIndex = 1;
            rdMobile.TabStop = true;
            rdMobile.Text = "Mobile";
            rdMobile.UseVisualStyleBackColor = true;
            // 
            // rdWeb
            // 
            rdWeb.AutoSize = true;
            rdWeb.Location = new Point(6, 30);
            rdWeb.Name = "rdWeb";
            rdWeb.Size = new Size(69, 26);
            rdWeb.TabIndex = 0;
            rdWeb.TabStop = true;
            rdWeb.Text = "Web";
            rdWeb.UseVisualStyleBackColor = true;
            // 
            // gbStatus
            // 
            gbStatus.Controls.Add(rdDesativado);
            gbStatus.Controls.Add(rdAtivo);
            gbStatus.Font = new Font("Arial", 14.25F);
            gbStatus.Location = new Point(66, 324);
            gbStatus.Name = "gbStatus";
            gbStatus.Size = new Size(243, 97);
            gbStatus.TabIndex = 3;
            gbStatus.TabStop = false;
            gbStatus.Text = "STATUS";
            // 
            // rdDesativado
            // 
            rdDesativado.AutoSize = true;
            rdDesativado.Location = new Point(97, 48);
            rdDesativado.Name = "rdDesativado";
            rdDesativado.Size = new Size(123, 26);
            rdDesativado.TabIndex = 1;
            rdDesativado.TabStop = true;
            rdDesativado.Text = "Desativado";
            rdDesativado.UseVisualStyleBackColor = true;
            // 
            // rdAtivo
            // 
            rdAtivo.AutoSize = true;
            rdAtivo.Location = new Point(6, 48);
            rdAtivo.Name = "rdAtivo";
            rdAtivo.Size = new Size(70, 26);
            rdAtivo.TabIndex = 0;
            rdAtivo.TabStop = true;
            rdAtivo.Text = "Ativo";
            rdAtivo.UseVisualStyleBackColor = true;
            rdAtivo.CheckedChanged += rdAtivo_CheckedChanged;
            // 
            // txtNomeCurso
            // 
            txtNomeCurso.Font = new Font("Arial", 14.25F);
            txtNomeCurso.Location = new Point(172, 120);
            txtNomeCurso.Name = "txtNomeCurso";
            txtNomeCurso.Size = new Size(201, 29);
            txtNomeCurso.TabIndex = 4;
            // 
            // cmbTurma
            // 
            cmbTurma.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTurma.Font = new Font("Arial", 14.25F);
            cmbTurma.FormattingEnabled = true;
            cmbTurma.Items.AddRange(new object[] { "Matutino", "Vespertino", "Noturno" });
            cmbTurma.Location = new Point(109, 169);
            cmbTurma.Name = "cmbTurma";
            cmbTurma.Size = new Size(200, 30);
            cmbTurma.TabIndex = 5;
            // 
            // toolStrip1
            // 
            toolStrip1.Items.AddRange(new ToolStripItem[] { btnNovo, toolStripSeparator1, btnSalvar, toolStripSeparator2, btnListar, toolStripSeparator3, btnExcluir });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(405, 71);
            toolStrip1.TabIndex = 6;
            toolStrip1.Text = "toolStrip1";
            toolStrip1.ItemClicked += toolStrip1_ItemClicked;
            // 
            // btnNovo
            // 
            btnNovo.DisplayStyle = ToolStripItemDisplayStyle.Image;
            btnNovo.Image = (Image)resources.GetObject("btnNovo.Image");
            btnNovo.ImageScaling = ToolStripItemImageScaling.None;
            btnNovo.ImageTransparentColor = Color.Magenta;
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(68, 68);
            btnNovo.Text = "Novo";
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(6, 71);
            // 
            // btnSalvar
            // 
            btnSalvar.DisplayStyle = ToolStripItemDisplayStyle.Image;
            btnSalvar.Image = (Image)resources.GetObject("btnSalvar.Image");
            btnSalvar.ImageScaling = ToolStripItemImageScaling.None;
            btnSalvar.ImageTransparentColor = Color.Magenta;
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(68, 68);
            btnSalvar.Text = "Salvar";
            // 
            // toolStripSeparator2
            // 
            toolStripSeparator2.Name = "toolStripSeparator2";
            toolStripSeparator2.Size = new Size(6, 71);
            // 
            // btnListar
            // 
            btnListar.DisplayStyle = ToolStripItemDisplayStyle.Image;
            btnListar.Image = (Image)resources.GetObject("btnListar.Image");
            btnListar.ImageScaling = ToolStripItemImageScaling.None;
            btnListar.ImageTransparentColor = Color.Magenta;
            btnListar.Name = "btnListar";
            btnListar.Size = new Size(68, 68);
            btnListar.Text = "Listar";
            // 
            // toolStripSeparator3
            // 
            toolStripSeparator3.Name = "toolStripSeparator3";
            toolStripSeparator3.Size = new Size(6, 71);
            // 
            // btnExcluir
            // 
            btnExcluir.DisplayStyle = ToolStripItemDisplayStyle.Image;
            btnExcluir.Image = (Image)resources.GetObject("btnExcluir.Image");
            btnExcluir.ImageScaling = ToolStripItemImageScaling.None;
            btnExcluir.ImageTransparentColor = Color.Magenta;
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(68, 68);
            btnExcluir.Text = "Excluir";
            // 
            // FrmCadCursos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(405, 473);
            Controls.Add(toolStrip1);
            Controls.Add(cmbTurma);
            Controls.Add(txtNomeCurso);
            Controls.Add(gbStatus);
            Controls.Add(gbTipo);
            Controls.Add(lblTurma);
            Controls.Add(lblNomeCurso);
            Name = "FrmCadCursos";
            Text = "FrmCadCursos";
            Load += FrmCadCursos_Load;
            gbTipo.ResumeLayout(false);
            gbTipo.PerformLayout();
            gbStatus.ResumeLayout(false);
            gbStatus.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNomeCurso;
        private Label lblTurma;
        private GroupBox gbTipo;
        private GroupBox gbStatus;
        private TextBox txtNomeCurso;
        private ComboBox cmbTurma;
        private ToolStrip toolStrip1;
        private ToolStripButton btnNovo;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripButton btnSalvar;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripButton btnListar;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripButton btnExcluir;
        private RadioButton rdMobile;
        private RadioButton rdWeb;
        private RadioButton rdDesativado;
        private RadioButton rdAtivo;
    }
}