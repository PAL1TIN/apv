using ProjetoCursos.view;

namespace ProjetoCursos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        private void cURSOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCadCursos filho = new FrmCadCursos();
            filho.MdiParent = this;
            filho.Show();
        }

        private void sAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            String titulo = "Encerrar programa";
            
            MessageBoxButtons botao = MessageBoxButtons.YesNo;
            DialogResult resultado = MessageBox.Show("Quer mesmo sair?", titulo, botao);

            if(resultado == DialogResult.Yes)
            {
                Close();
            }

            
        }
    }
}
